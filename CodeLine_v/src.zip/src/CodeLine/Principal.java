package CodeLine;

public interface Principal {
    
    void anadir(Account a);
    void eliminar(Account a);
    void buscar(Account a); 
}
